This script will:
	- Replace all occurrences in src/classes/ of the given Apex class with the new class name
	- Rename the old Apex class and metadata files with the new class name

Usage:
- Copy this file to your project directory (it should be on the same level as the src/ directory).
- Run: ./rename_class OldClassMame NewClassName
